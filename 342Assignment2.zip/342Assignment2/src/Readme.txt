Reflections

a. I probably spent 16-20 hours on this assignment
b. I struggled to find the motivation to do this, as we are nearing the end of the quarter. However, once I got started,
my coding flowed fairly well. I found it most difficult to create my ArrayHeap from scratch with so much functionality
to implement. Little edge cases kept tripping me up, but everything seems to be working now! I certainly used the
debugger heavily while stuck in some parts.
c. I believe I followed the requirements to a tee, considering that my compression ratios are identical to yours
in the two examples you have. Even though my tables look fairly different, I am surprised that my numbers are the same!
d. I would probably explore other types of trees besides Huffman to achieve even greater compression ratios if I could
do this assingment again.
e. The purose of this assignment is to force me to deeply understand Heaps, compression, priority queues, and even the
advantage of using a Heap, even though I did not implement it myself.
